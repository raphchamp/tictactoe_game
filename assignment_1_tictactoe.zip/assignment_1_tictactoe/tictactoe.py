"""
Tic Tac Toe Player
"""

import math
import copy

X = "X"
O = "O"
EMPTY = None


def initial_state():
    """
    Returns starting state of the board.
    """
    return [[EMPTY, EMPTY, EMPTY],
            [EMPTY, EMPTY, EMPTY],
            [EMPTY, EMPTY, EMPTY]]


def player(board):
    """
    Returns player who has the next turn on a board.
    """
    next_turn = X
    cpt_x = 0
    cpt_o = 0
    for i in range(3):
       for j in range(3):
        if(board[i][j] == "X"):
            cpt_x += 1
        elif(board[i][j] == "O"):
            cpt_o += 1
    if(cpt_o < cpt_x):
        next_turn = O  
    return next_turn



def actions(board):
    """
    Returns set of all possible actions (i, j) available on the board.
    """
    possibilities = set()
    for i in range(3):
       for j in range(3):
           if(board[i][j] == EMPTY):
               possibilities.add((i, j))

    return possibilities



def result(board, action):
    """
    Returns the board that results from making move (i, j) on the board.
    """
    temp = copy.deepcopy(board)
    actions_len = len(actions(board))
    # if(actions_len==len(actions(board)-{action})):
    #     raise Exception

    temp[action[0]][action[1]] = player(board)
    return temp



def winner(board):
    """
    Returns the winner of the game, if there is one.
    """
    turn=EMPTY
    if(player(board)==X):
        turn=O
    else:
        turn=X
    isWinner = EMPTY
    cpt = 0
  
    for i in range(3):
        cpt_p = 0
        for j in range(3):
            if (board[i][j] == turn):
                cpt_p += 1
        if(cpt_p == 3):
            isWinner = turn
         
    
    for j in range(3):
        cpt_p = 0
        for i in range(3):
            if (board[i][j] == turn):
                cpt_p += 1
        if(cpt_p == 3):
            isWinner = turn
            
    
    for j in range(1):
       cpt_p = 0
       for i in range(3):
           if (board[i][i] == turn):
              
               cpt_p += 1
       if(cpt_p == 3):
           isWinner = turn
          
     
    for j in range(1):
       cpt_p = 0
       for i in range(3):
           if (board[i][2-i] == turn):
            
               cpt_p += 1
       if(cpt_p == 3):
           isWinner = turn           
          
     
                 
    return isWinner      

def terminal(board):
    """
    Returns True if game is over, False otherwise.
    """
    isOver = False
    emptyCount = 0

    for i in range(3):
        for j in range(3):
            if board[i][j] == "None":
                emptyCount += 1

    if(winner(board) != EMPTY or emptyCount > 0):
        isOver = True
   

    return isOver

def utility(board):
    """
    Returns 1 if X has won the game, -1 if O has won, 0 otherwise.
    """
    score = 0

    if (winner(board) == X):
        score = 1

    elif(winner(board) == O):
        score = -1

    return score



def minimax(board, depth=2, Player=False, alpha=float('-inf'), beta=float('inf')):
    """
    Returns the optimal action for the current player on the board.
    """
    opti_action=(0,0)
    if(depth == 0 or terminal(board)):
        return utility(board), None

    if Player:
        score = float('-inf')
        for action in actions(board):
            next_board = result(board, action)

            opti_score = minimax(next_board, depth-1, False, alpha, beta)[0]
            if opti_score > score:
                score = opti_score
                opti_action = action
              
            if score >= beta:
                break
            alpha = max(alpha, score)
            
    else:
         score = float('inf')
         
         for action in actions(board):
             next_board = result(board, action)
            
             opti_score = minimax(next_board, depth-1, True, alpha, beta)[0]
               
             if opti_score < score:
                 score = opti_score
                 opti_action = action
                
             if score <= alpha:
                 break
             beta = min(beta, score)
    
    return score, opti_action
